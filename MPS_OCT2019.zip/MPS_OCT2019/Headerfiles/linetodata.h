double *linetodata(char line[], int lenline, int *size);
