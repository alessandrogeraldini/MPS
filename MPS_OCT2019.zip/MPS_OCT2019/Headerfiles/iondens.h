int iondens(int dodistfunc);
