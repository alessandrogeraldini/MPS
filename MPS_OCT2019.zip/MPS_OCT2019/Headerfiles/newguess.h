int newguess();
