fyz = importdata('f0yz.txt');
fyz = fyz.';
vy = importdata('vy0.txt');
vz = importdata('vz0.txt');
fyz = fyz*4; % multiply by 4 due to weird way distribution function F is defined
        % in the code

fun = @(x,y) interp2(vy,vz,fyz,x,y);

q = integral2(fun, vy(1), vy(length(vy)), vz(1), vz(length(vz)));

fyz = fyz/q;

contourf(vy, vz, fyz);
set(gca,'Color',[0.2081    0.1663    0.5292]); 
% colour the background with same colour as zero
axis equal;
xlim([0, 4]);
ylim([0, 4.5]);
xlabel('v_y/v_{t,i}')
ylabel('v_z/v_{t,i}')
title('f_{0yz}/(n_0 / v_{t,i}^2)')
colorbar

hold on

saveas(gca,'fig_f0yz.pdf')

% uncomment if want to plot Bohm speed
% Te = ?
% vel = linspace(0.0, 5.0, 500);
% %vB = sqrt(Te/2.0)*ones(500);
% plot(vel,vB, ':w'); %, 'Linewidth', 1.0);
% plot(vB,vel, ':w'); %, 'Linewidth', 1.0);


%%%%%%%

% Part below calculate distribution function for Te = 0 (HOT IONS)
% vyalpha05Te0 = linspace(0.0, 5.0, 1000);
% vzalpha05Te0 = linspace(0.0, 5.0, 1000);
% fu = @(x,y) sqrt(x*y*alpha*4*pi)*exp(-x^2)*exp(-y^2);
% Falpha05Te0= zeros(length(vyalpha05Te0), length(vzalpha05Te0));
% for i = 1:length(vzalpha05Te0)
%     for j = 1:length(vyalpha05Te0)
%         Falpha05Te0(i,j) = fu(vyalpha05Te0(j), vzalpha05Te0(i));
%     end
% end
% 
% 
% vyalpha05Te0  = vyalpha05Te0;
% vzalpha05Te0  = vzalpha05Te0;
% Falpha05Te0 = Falpha05Te0*4 % divide by 2 to normalise by sound speed instead of thermal speed
%         % and multiply by 4 due to weird way distribution function F is defined
%         % in the code
% 
% funalpha05Te0 = @(x,y) interp2(vyalpha05Te0,vzalpha05Te0,Falpha05Te0,x,y)
% 
% qalpha05Te5 = integral2(funalpha05Te0, vyalpha05Te0(1), vyalpha05Te0(length(vyalpha05Te0)), vzalpha05Te0(1), vzalpha05Te0(length(vzalpha05Te0)))
% 
% Falpha05Te0 = Falpha05Te0/qalpha05Te0
% 
% funalpha05Te0B = @(x,y) funalpha05Te0(x,y).*sqrt(x.^2 + y.^2) 
% 
% qalpha05Te0B = integral2(funalpha05Te0B, vyalpha05Te0(1), vyalpha05Te0(length(vyalpha05Te0)), vzalpha05Te0(1), vzalpha05Te0(length(vzalpha05Te0)))
% 
% planeTe0 = contourf(vyalpha05Te0, vzalpha05Te0, Falpha05Te0)
% pbaspect([1 1 1])
% xlim([0, 4])
% ylim([0, 4.5])
% caxis([0 max(Falpha05Te5(:))])
% 
% 
