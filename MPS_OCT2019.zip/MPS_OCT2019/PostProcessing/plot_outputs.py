import numpy as np
import scipy.integrate as int
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import scipy.special as scsp
plt.rc('text', usetex=True)
plt.rc('font',**{'family':'serif','serif':['Palatino']})

alpha, Te = np.loadtxt('../inputfile.txt')
Ts = 1.0+Te

file = 'niout.txt'
filephi = 'phidataold.txt'
file_fvx = 'f0x.txt'

vx, f = np.loadtxt(file_fvx, unpack = 'True')

#########################################

#### Plot of distribution function at Debye sheath entrance

plt.rc('xtick',labelsize=16)
plt.rc('ytick',labelsize=16)
plt.plot(vx, f, lw = 2.0)
plt.xlim(-0.5, 4.0)
plt.xlabel(r'$|v_x|/v_{t,i}$', fontsize=25)
plt.ylabel(r'$f_0(v_x)/(n_0/v_{t,i})$', fontsize=25, verticalalignment = 'bottom', horizontalalignment = 'center')
plt.tight_layout()
plt.savefig('fig_f0x.pdf', dpi = 100)
plt.clf()

gg, nitotal, niclosed, niopen = np.loadtxt(file, unpack = 'True')
gg2, phi = np.loadtxt(filephi, unpack = 'True')
x2 = gg2**2
x = gg**2
n = len(phi)
phip = range(n)
xi = range(n)
phip[0] = (phi[1] - phi[0])/(x2[1]-x2[0]) + (x2[0] - x2[1])*((phi[2] - phi[1])/(x2[2]-x2[1]) - (phi[1] - phi[0])/(x2[1]-x2[0]))/(x2[2]-x2[1]); 
for i in range(1,n-1):
	phip[i] = 0.5*(phi[i+1] - phi[i])/(x2[i+1] - x2[i]) + 0.5*(phi[i] - phi[i-1])/(x2[i] - x2[i-1]);

phip[n-1] = 0.5*(phi[n-1] - phi[n-2])/(x2[n-1] - x2[n-2]) + 0.5*(phi[n-2] - phi[n-3])/(x2[n-2] - x2[n-3])

for i in range(n):
	xi[i] = x2[i] + phip[i]/2.0;

plt.plot(x2, phi)
plt.xlim(0.0, 8.0*np.sqrt(Ts))
plt.xlabel(r'$x/\rho_i$', fontsize=25)
plt.ylabel(r'$e\phi/T_e$', fontsize=25, verticalalignment = 'bottom', horizontalalignment = 'center')
plt.tight_layout()
plt.savefig('fig-phi.pdf', dpi = 100)
plt.clf()

plt.plot(x2, xi)
plt.xlim(0.0, 8.0*np.sqrt(Ts))
plt.xlabel(r'$x/\rho_i$', fontsize=25)
plt.ylabel(r'$\xi$', fontsize=25, verticalalignment = 'bottom', horizontalalignment = 'center')
plt.tight_layout()
plt.savefig('fig-xi.pdf', dpi = 100)
plt.clf()

ne = [np.exp(p/Te) for p in phi]
plt.plot(x, niclosed)
plt.plot(x, niopen)
plt.plot(x, nitotal)
plt.plot(x2, ne)
plt.xlim(0.0, 8.0*np.sqrt(Ts))
plt.ylim(0.0, 1.0)
plt.xlabel(r'$x/\rh0_i$', fontsize=25)
plt.ylabel(r'$n_i$', fontsize=25, verticalalignment = 'bottom', horizontalalignment = 'center')
plt.tight_layout()
plt.savefig('fig-ni.pdf', dpi = 100)

